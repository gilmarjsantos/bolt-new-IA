import React, { useState } from 'react';
import { Menu, Phone, Clock, MapPin, Instagram, Facebook } from 'lucide-react';

const pasteis = [
  {
    name: 'Pastel de Carne',
    price: 'R$ 8,00',
    description: 'Recheado com carne moída temperada',
    image: 'https://images.unsplash.com/photo-1628824851008-ec3ab4b45d1f?w=800&auto=format&fit=crop'
  },
  {
    name: 'Pastel de Queijo',
    price: 'R$ 7,00',
    description: 'Queijo mussarela derretido',
    image: 'https://images.unsplash.com/photo-1604478579007-7c8cf93b0797?w=800&auto=format&fit=crop'
  },
  {
    name: 'Pastel de Frango',
    price: 'R$ 8,00',
    description: 'Frango desfiado com catupiry',
    image: 'https://images.unsplash.com/photo-1619221882220-947b3d3c8861?w=800&auto=format&fit=crop'
  }
];

function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically handle the form submission
    console.log('Form submitted:', formData);
    alert('Mensagem enviada com sucesso!');
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-amber-50">
      {/* Header */}
      <header className="bg-amber-800 text-white py-4 px-6 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Pastelaria Delícia</h1>
          <nav className="hidden md:flex space-x-6">
            <a href="#menu" className="hover:text-amber-200">Menu</a>
            <a href="#sobre" className="hover:text-amber-200">Sobre</a>
            <a href="#contato" className="hover:text-amber-200">Contato</a>
          </nav>
          <Menu className="md:hidden w-6 h-6" />
        </div>
      </header>

      {/* Hero Section */}
      <div className="relative h-[60vh] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1517433670267-08bbd4be890f?w=1600&auto=format&fit=crop")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-5xl font-bold mb-4">Os Melhores Pastéis da Cidade</h2>
            <p className="text-xl">Feitos na hora, sempre quentinhos e crocantes</p>
          </div>
        </div>
      </div>

      {/* Menu Section */}
      <section id="menu" className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-amber-900">Nosso Menu</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {pasteis.map((pastel) => (
            <div key={pastel.name} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img src={pastel.image} alt={pastel.name} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{pastel.name}</h3>
                <p className="text-gray-600 mb-4">{pastel.description}</p>
                <p className="text-amber-800 font-bold">{pastel.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="bg-amber-100 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8 text-amber-900">Sobre Nós</h2>
          <p className="text-center max-w-2xl mx-auto text-lg text-amber-900">
            Desde 1990, a Pastelaria Delícia tem servido os mais deliciosos pastéis da região.
            Nossa receita tradicional, passada de geração em geração, garante a qualidade e o
            sabor único que nossos clientes adoram.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-amber-900">Contato</h2>
        
        {/* Contact Info Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-16">
          <div className="flex flex-col items-center text-center">
            <Phone className="w-8 h-8 text-amber-800 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Telefone</h3>
            <p>(11) 99999-9999</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <Clock className="w-8 h-8 text-amber-800 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Horário</h3>
            <p>Terça a Domingo</p>
            <p>11h às 22h</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <MapPin className="w-8 h-8 text-amber-800 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Endereço</h3>
            <p>Rua dos Pastéis, 123</p>
            <p>Centro - São Paulo</p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
          <h3 className="text-2xl font-semibold mb-6 text-amber-900 text-center">Envie uma Mensagem</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Nome Completo
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="Seu nome"
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="seu@email.com"
              />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Telefone
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="(11) 99999-9999"
              />
            </div>
            
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Mensagem
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="Digite sua mensagem aqui..."
              />
            </div>
            
            <button
              type="submit"
              className="w-full bg-amber-800 text-white py-3 px-6 rounded-md hover:bg-amber-700 transition-colors duration-200"
            >
              Enviar Mensagem
            </button>
          </form>
        </div>

        <div className="flex justify-center space-x-6 mt-12">
          <a href="#" className="text-amber-800 hover:text-amber-600">
            <Instagram className="w-8 h-8" />
          </a>
          <a href="#" className="text-amber-800 hover:text-amber-600">
            <Facebook className="w-8 h-8" />
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 Pastelaria Delícia. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;